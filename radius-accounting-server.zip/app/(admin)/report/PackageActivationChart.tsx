'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function PackageActivationChart({ data }: { data: any[] }) { return <div>Chart</div>; }
