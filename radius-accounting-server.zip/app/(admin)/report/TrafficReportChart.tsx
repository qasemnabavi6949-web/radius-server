'use client';

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function TrafficReportChart({ data }: { data: any[] }) {
  // Calculate max MB to format YAxis
  const maxBytes = Math.max(...data.map(d => d.total || 0));
  const isBytes = maxBytes < 1024;
  const isKB = maxBytes >= 1024 && maxBytes < 1024 * 1024;
  const divisor = isBytes ? 1 : isKB ? 1024 : 1024 * 1024;
  const suffix = isBytes ? 'B' : isKB ? 'KB' : 'MB';

  const chartData = data.map(d => ({
    ...d,
    download: parseFloat((d.download / divisor).toFixed(2)),
    upload: parseFloat((d.upload / divisor).toFixed(2)),
    total: parseFloat((d.total / divisor).toFixed(2)),
    realTraffic: parseFloat((d.realTraffic / divisor).toFixed(2))
  }));

  const formatYAxis = (tickItem: any) => {
    return `${tickItem} ${suffix}`;
  };

  return <div>Chart</div>;
}
