'use client';

import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-900 p-4 font-sans text-center">
      <h2 className="text-4xl font-bold text-slate-100 mb-4">404</h2>
      <p className="text-slate-400 mb-8 text-lg">The page you are looking for does not exist.</p>
      <Link 
        href="/"
        className="px-6 py-2.5 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors shadow-sm"
      >
        Return Home
      </Link>
    </div>
  );
}
